#!/usr/bin/env bash
set -Eeuo pipefail

cd "$(dirname -- "${BASH_SOURCE[0]}")/.."
repo_root="$PWD"
run_id="${1:?provide a fresh run ID}"
model="${2:-qwen2_moe_14b}"
[[ "$run_id" =~ ^[A-Za-z0-9_.-]{1,32}$ ]]
case "$model" in qwen2_moe_14b|deepseek_v2_lite) ;; *) exit 2;; esac
root="$repo_root/runs/moe-capacity/$run_id"
[[ ! -e "$root" ]]
mkdir -p "$root"
python=/opt/conda/envs/sjw_ckpt_grouping/bin/python
remote=172.20.8.2
port="$("$python" -c 'import socket; s=socket.socket(); s.bind(("",0)); print(s.getsockname()[1])')"
local_session="mc-${run_id}-17"
remote_session="mc-${run_id}-8"
publish="${CKPT_CAPACITY_PUBLISH:-0}"
service_local="mcs-${run_id}-17"
service_remote="mcs-${run_id}-8"
owned_local=0 owned_remote=0 owned_service_local=0 owned_service_remote=0
cleanup() {
    if (( owned_local )); then tmux kill-session -t "$local_session" 2>/dev/null || true; fi
    if (( owned_remote )); then ssh -o BatchMode=yes "$remote" tmux kill-session -t "$remote_session" 2>/dev/null || true; fi
    if (( owned_service_local )); then tmux kill-session -t "$service_local" 2>/dev/null || true; fi
    if (( owned_service_remote )); then ssh -o BatchMode=yes "$remote" tmux kill-session -t "$service_remote" 2>/dev/null || true; fi
    # torchrun descendants may outlive the tmux shell on a failed capacity run.
    if (( owned_local || owned_service_local )); then
        pkill -TERM -f "^/opt/conda/envs/sjw_ckpt_grouping/bin/python(3.10)? .*${root}/" || true
    fi
    if (( owned_remote || owned_service_remote )); then
        printf -v pattern '%q' "^/opt/conda/envs/sjw_ckpt_grouping/bin/python(3.10)? .*${root}/"
        ssh -o BatchMode=yes "$remote" "pkill -TERM -f $pattern || true" || true
    fi
}
trap cleanup EXIT
[[ -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)" ]]
[[ -z "$(ssh -o BatchMode=yes "$remote" nvidia-smi --query-compute-apps=pid --format=csv,noheader)" ]]
common=(env CKPT_RUNTIME_ONLY=1 CKPT_RECORD_STEP_METRICS=1
    NODE_IDS=17,8 NPROC_PER_NODE=8 MASTER_ADDR=172.20.17.2 MASTER_PORT="$port"
    RUN_ID="$run_id" LOG_DIR="$root/torchrun"
    tools/launch_ckpt_grouping.sh examples/checkpoint_grouping/run_workload.py
    --model "$model" --pp 4 --tp 1 --dp 4 --mesh-order pp-dp
    --expert-parallel-size 2 --role-aware-zero1 --zero_stage 1
    --dataset-size 1024 --per_device_train_batch_size 1 --gradient_accumulation_steps 8
    --max_steps 1 --num_train_epochs 1 --seq_length 128 --seed 20261007
    --dataloader_num_workers 0 --save false --logging_steps 1 --report_to none
    --disable_tqdm true --no_tie_modules true --bf16 true --adafactor false
    --lr_scheduler_type constant --learning_rate 0.0001 --weight_decay 0.0
    --adam_beta1 0.9 --adam_beta2 0.95 --adam_epsilon 1e-8
    --experiment-metadata "$root/metadata.json" --output_dir "$root/trainer-output")
if [[ "$publish" == 1 ]]; then
    service_args=(env PYTHONPATH=.:process_monitor "$python"
        examples/checkpoint_grouping/run_replica_service.py
        --bind 0.0.0.0 --port 0 --max-store-mib 262144 --retained-epochs 1)
    tools/run_in_tmux.sh "$service_local" "$root/service17.log" -- "${service_args[@]}" --ready-file "$root/service17.ready"
    owned_service_local=1
    printf -v quoted '%q ' tools/run_in_tmux.sh "$service_remote" "$root/service8.log" -- "${service_args[@]}" --ready-file "$root/service8.ready"
    ssh -o BatchMode=yes "$remote" "cd $(printf '%q' "$repo_root") && $quoted"
    owned_service_remote=1
    for _ in {1..60}; do
        [[ -s "$root/service17.ready" && -s "$root/service8.ready" ]] && break
        sleep 1
    done
    local_port="$(<"$root/service17.ready")"
    remote_port="$(<"$root/service8.ready")"
    endpoints="$("$python" -c 'import json,sys; print(json.dumps(sys.argv[1:]))' "172.20.17.2:${local_port##*:}" "172.20.8.2:${remote_port##*:}")"
    printf '%s\n' "$endpoints" > "$root/endpoints.json"
    common=(env CKPT_REPLICA_ENDPOINTS="$endpoints" CKPT_ZERO1_LOCATOR="$root/locator.json"
        CKPT_ZERO1_OBJECT_PUBLISH_STEPS=1 CKPT_ZERO1_ARM=adacheck_fixed
        CKPT_MOE_ADACHECK_GROUPING=1 CKPT_ZERO1_SERIAL_PUBLISH=1
        CKPT_ZERO1_EXPORT_INVENTORY=0 CKPT_MOE_CONTROL_TIMEOUT_SECONDS=1800
        CKPT_OBJECT_SERVICE_TIMEOUT_SECONDS=600 "${common[@]:1}")
fi
printf '%q ' "${common[@]}" > "$root/command.txt"
tools/run_in_tmux.sh "$local_session" "$root/node17.log" -- env NODE_RANK=0 "${common[@]}"
owned_local=1
printf -v quoted '%q ' tools/run_in_tmux.sh "$remote_session" "$root/node8.log" -- env NODE_RANK=1 "${common[@]}"
ssh -o BatchMode=yes "$remote" "cd $(printf '%q' "$repo_root") && $quoted"
owned_remote=1
for ((elapsed=0; elapsed<2700; elapsed+=5)); do
    nvidia-smi --query-gpu=timestamp,index,memory.used,utilization.gpu --format=csv,noheader >> "$root/node17-gpu.csv"
    ssh -o BatchMode=yes "$remote" nvidia-smi --query-gpu=timestamp,index,memory.used,utilization.gpu --format=csv,noheader >> "$root/node8-gpu.csv"
    available17="$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)"
    available8="$(ssh -o BatchMode=yes "$remote" "awk '/^MemAvailable:/ {print \$2}' /proc/meminfo")"
    printf '%s,%s,%s\n' "$(date -u +%FT%TZ)" "$available17" "$available8" >> "$root/host-available-KiB.csv"
    if (( available17 < 25165824 || available8 < 25165824 )); then
        printf 'host available RAM below24GiB\n' > "$root/FAILED"
        exit 1
    fi
    rc17="$(sed -n 's/^exit_code=//p' "$root/node17.log.status" 2>/dev/null || true)"
    rc8="$(sed -n 's/^exit_code=//p' "$root/node8.log.status" 2>/dev/null || true)"
    if [[ -n "$rc17" && "$rc17" != 0 || -n "$rc8" && "$rc8" != 0 ]]; then
        printf 'node17=%s node8=%s\n' "$rc17" "$rc8" > "$root/FAILED"
        exit 1
    fi
    if [[ "$rc17" == 0 && "$rc8" == 0 ]]; then
        if [[ "$publish" == 1 ]]; then
            "$python" - "$root" <<'PY'
import json, sys
from pathlib import Path
from Merak.core.checkpoint.replica_service import ReplicaServiceClient
root = Path(sys.argv[1])
locator = json.loads((root / 'locator.json').read_text())
assert locator['epoch'] == 1 and locator['model_aliases_applied']
stats = [ReplicaServiceClient.from_endpoint(endpoint).stats()
         for endpoint in json.loads((root / 'endpoints.json').read_text())]
assert all(row['record_count'] == 17 for row in stats)
(root / 'service-stats.json').write_text(json.dumps(stats, indent=2) + '\n')
PY
            printf 'full-model epoch1 publication capacity; restore untested\n' > "$root/COMPLETE"
        else
            printf 'full-model training capacity only; no checkpoint publication\n' > "$root/COMPLETE"
        fi
        exit 0
    fi
    sleep 5
done
printf 'timeout\n' > "$root/FAILED"
exit 1
