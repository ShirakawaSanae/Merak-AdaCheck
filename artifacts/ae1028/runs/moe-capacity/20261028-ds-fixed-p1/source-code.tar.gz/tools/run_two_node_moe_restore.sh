#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname -- "${BASH_SOURCE[0]}")/.."
repo_root="$PWD"
source_root="$(cd "${1:?source run directory}" && pwd)"
run_id="${2:?fresh restore run ID}"
[[ "$run_id" =~ ^[A-Za-z0-9_.-]{1,32}$ ]]
root="$repo_root/runs/moe-restore/$run_id"
[[ ! -e "$root" ]]
mkdir -p "$root"
python=/opt/conda/envs/sjw_ckpt_grouping/bin/python
remote=172.20.8.2
model="$("$python" -c 'import json,sys; print(json.load(open(sys.argv[1]))["workload"]["name"])' "$source_root/metadata.json")"
epoch="$("$python" -c 'import json,sys; print(json.load(open(sys.argv[1]))["epoch"])' "$source_root/locator.json")"
endpoints="$(<"$source_root/endpoints.json")"
port="$("$python" -c 'import socket; s=socket.socket(); s.bind(("",0)); print(s.getsockname()[1])')"
local_session="mr-${run_id}-17"
remote_session="mr-${run_id}-8"
owned_local=0 owned_remote=0
cleanup() {
    if (( owned_local )); then
        tmux kill-session -t "$local_session" 2>/dev/null || true
        pkill -TERM -f "^/opt/conda/envs/sjw_ckpt_grouping/bin/python(3.10)? .*${root}/" || true
    fi
    if (( owned_remote )); then
        ssh -o BatchMode=yes "$remote" tmux kill-session -t "$remote_session" 2>/dev/null || true
        printf -v pattern '%q' "^/opt/conda/envs/sjw_ckpt_grouping/bin/python(3.10)? .*${root}/"
        ssh -o BatchMode=yes "$remote" "pkill -TERM -f $pattern || true" || true
    fi
}
trap cleanup EXIT
[[ -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)" ]]
[[ -z "$(ssh -o BatchMode=yes "$remote" nvidia-smi --query-compute-apps=pid --format=csv,noheader)" ]]
common=(env CKPT_RUNTIME_ONLY=1 CKPT_RECORD_STEP_METRICS=1
    CKPT_REPLICA_ENDPOINTS="$endpoints" CKPT_ZERO1_LOCATOR="$source_root/locator.json"
    CKPT_ZERO1_OBJECT_RESTORE_EPOCH="$epoch" CKPT_OBJECT_SURVIVING_HOST=0
    CKPT_ZERO1_TARGET_ONLY_RESTORE=1 CKPT_ZERO1_SERIAL_RESTORE="${CKPT_ZERO1_SERIAL_RESTORE:-1}"
    CKPT_MOE_ADACHECK_GROUPING=1 CKPT_MOE_CONTROL_TIMEOUT_SECONDS=1800
    CKPT_OBJECT_SERVICE_TIMEOUT_SECONDS=600 NODE_IDS=17,8 NPROC_PER_NODE=8
    MASTER_ADDR=172.20.17.2 MASTER_PORT="$port" RUN_ID="$run_id" LOG_DIR="$root/torchrun"
    tools/launch_ckpt_grouping.sh examples/checkpoint_grouping/run_workload.py
    --model "$model" --pp 4 --tp 1 --dp 4 --mesh-order pp-dp
    --expert-parallel-size 2 --role-aware-zero1 --zero_stage 1
    --dataset-size 1024 --per_device_train_batch_size 1 --gradient_accumulation_steps 8
    --max_steps "$((epoch+1))" --num_train_epochs 1 --seq_length 128 --seed 20261007
    --dataloader_num_workers 0 --save false --logging_steps 1 --report_to none
    --disable_tqdm true --no_tie_modules true --bf16 true --adafactor false
    --lr_scheduler_type constant --learning_rate 0.0001 --weight_decay 0.0
    --adam_beta1 0.9 --adam_beta2 0.95 --adam_epsilon 1e-8
    --experiment-metadata "$root/metadata.json" --output_dir "$root/trainer-output")
if [[ "${CKPT_MOE_FINAL_DIGEST:-0}" == 1 ]]; then
    common=(env CKPT_FINAL_DIGEST_DIR="$root/digests" "${common[@]:1}")
fi
printf '%q ' "${common[@]}" > "$root/command.txt"
printf '%s\n' "$source_root" > "$root/source-run.txt"
tools/run_in_tmux.sh "$local_session" "$root/node17.log" -- env NODE_RANK=0 "${common[@]}"
owned_local=1
printf -v quoted '%q ' tools/run_in_tmux.sh "$remote_session" "$root/node8.log" -- env NODE_RANK=1 "${common[@]}"
ssh -o BatchMode=yes "$remote" "cd $(printf '%q' "$repo_root") && $quoted"
owned_remote=1
for ((elapsed=0; elapsed<5400; elapsed+=5)); do
    nvidia-smi --query-gpu=timestamp,index,memory.used --format=csv,noheader >> "$root/node17-gpu.csv"
    ssh -o BatchMode=yes "$remote" nvidia-smi --query-gpu=timestamp,index,memory.used --format=csv,noheader >> "$root/node8-gpu.csv"
    a="$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)"
    b="$(ssh -o BatchMode=yes "$remote" "awk '/^MemAvailable:/ {print \$2}' /proc/meminfo")"
    printf '%s,%s,%s\n' "$(date -u +%FT%TZ)" "$a" "$b" >> "$root/host-available-KiB.csv"
    if ((a<25165824 || b<25165824)); then printf 'memory budget\n' > "$root/FAILED"; exit 1; fi
    rc17="$(sed -n 's/^exit_code=//p' "$root/node17.log.status" 2>/dev/null || true)"
    rc8="$(sed -n 's/^exit_code=//p' "$root/node8.log.status" 2>/dev/null || true)"
    if [[ -n "$rc17" && "$rc17" != 0 || -n "$rc8" && "$rc8" != 0 ]]; then
        printf 'node17=%s node8=%s\n' "$rc17" "$rc8" > "$root/FAILED"; exit 1
    fi
    if [[ "$rc17" == 0 && "$rc8" == 0 ]]; then
        "$python" - "$root" "$epoch" <<'PY'
import json, math, re, sys
from pathlib import Path
root, epoch = Path(sys.argv[1]), int(sys.argv[2])
files = sorted((root / 'trainer-output/zero1-step-metrics').glob('rank_*.jsonl'))
rows = [json.loads(line) for path in files for line in path.read_text().splitlines()]
assert len(files) == len(rows) == 16 and all(row['step'] == epoch+1 for row in rows)
metrics = json.loads((root / 'trainer-output/zero1-object-metrics.jsonl').read_text())
assert metrics['event'] == 'fresh_restore' and metrics['epoch'] == epoch
losses = re.findall(r'steps: \d+ loss: (\S+)', (root / 'node17.log').read_text())
assert losses and all(math.isfinite(float(value)) for value in losses)
PY
        printf 'full-model fresh restore plus next step; reference comparison pending\n' > "$root/COMPLETE"
        exit 0
    fi
    sleep 5
done
printf 'timeout\n' > "$root/FAILED"
exit 1
