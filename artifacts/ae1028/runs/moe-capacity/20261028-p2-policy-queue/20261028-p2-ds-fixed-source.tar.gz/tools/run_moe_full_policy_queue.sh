#!/usr/bin/env bash
set -Eeuo pipefail

cd "$(dirname -- "${BASH_SOURCE[0]}")/.."
campaign="${1:?provide a fresh campaign ID}"
[[ "$campaign" =~ ^[A-Za-z0-9_.-]{1,16}$ ]]
root="$PWD/runs/moe-capacity/${campaign}-policy-queue"
mkdir -p "$root"
[[ ! -e "$root/STARTED" ]]
date -u +%FT%TZ > "$root/STARTED"
trap 'rc=$?; if ((rc)); then printf "exit_code=%s\n" "$rc" > "$root/FAILED"; fi' EXIT

for spec in \
    'ds-fixed deepseek_v2_lite adacheck_fixed' \
    'ds-host deepseek_v2_lite host_global_fixed' \
    'ds-m1 deepseek_v2_lite m1' \
    'qwen-fixed qwen2_moe_14b adacheck_fixed' \
    'qwen-host qwen2_moe_14b host_global_fixed' \
    'qwen-m1 qwen2_moe_14b m1'; do
    read -r label model arm <<< "$spec"
    run_id="${campaign}-${label}"
    archive="$root/${run_id}-source.tar.gz"
    tar -czf "$archive" --exclude=__pycache__ --exclude='*.pyc' \
        Merak examples/checkpoint_grouping process_monitor/procguard \
        setup_experiment.sh tools/launch_ckpt_grouping.sh tools/run_in_tmux.sh \
        tools/run_two_node_moe_capacity.sh tools/run_two_node_moe_restore.sh \
        tools/run_moe_full_policy_queue.sh
    sha256sum "$archive" > "$archive.sha256"
    printf '%s START %s %s\n' "$(date -u +%FT%TZ)" "$run_id" "$arm"
    env CKPT_CAPACITY_PUBLISH=1 CKPT_CAPACITY_CHAIN_RESTORE=1 \
        CKPT_CAPACITY_STEPS=2 CKPT_CAPACITY_ARM="$arm" \
        CKPT_ZERO1_SERIAL_PUBLISH=host \
        bash tools/run_two_node_moe_capacity.sh "$run_id" "$model"
    [[ -f "runs/moe-capacity/$run_id/COMPLETE" ]]
    printf '%s COMPLETE %s\n' "$(date -u +%FT%TZ)" "$run_id"
done
date -u +%FT%TZ > "$root/COMPLETE"
